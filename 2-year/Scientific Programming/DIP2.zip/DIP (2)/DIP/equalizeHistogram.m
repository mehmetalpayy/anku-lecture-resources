function output = equalizeHistogram(img)
    [r,c] = size(img);
    output = zeros(r, c);
    histogram = histf(img);
    
    step1 = histogram / (r*c);
    step2 = zeros(1,256);
    
    for i=1:256	
        step2(i)=sum(step1(1:i));
    end
    
    eq_histogram = round(255* step2);

    for i=1:r	
        for j=1:c		
            output(i,j) = eq_histogram(img(i,j)+1);	
        end
    end
end