img = imread('moon_rgb.jpg');
img=rgb2gray(img);
out = histf(img); 
figure; 
subplot(1,2,1); imshow(img); 
subplot(1,2,2); bar(out);
