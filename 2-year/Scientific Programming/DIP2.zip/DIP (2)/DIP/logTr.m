function [output] = logTr(img)

c=1000;

output=c*log(1+(img));

end

