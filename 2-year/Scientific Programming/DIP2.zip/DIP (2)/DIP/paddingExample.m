im = imread('averaging.png');
im=rgb2gray(im);

% zero padding
result1 = imfilter(im, ones(15,15)/225, 'full');

result2 = imfilter(im, ones(15,15)/225, 'symmetric', 'full');
result3 = imfilter(im, ones(15,15)/225, 'replicate', 'full');
result4 = imfilter(im, ones(15,15)/225, 'circular', 'full');

figure;
subplot(2,2,1); imshow(uint8(result1));
subplot(2,2,2); imshow(uint8(result2));
subplot(2,2,3); imshow(uint8(result3));
subplot(2,2,4); imshow(uint8(result4));