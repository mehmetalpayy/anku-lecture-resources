function output = negative(img)

output=255-img;

end

