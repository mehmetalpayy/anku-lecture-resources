function [output] = threshold(img,thresholdValue)

    output=(img>thresholdValue)*255;
    
end

