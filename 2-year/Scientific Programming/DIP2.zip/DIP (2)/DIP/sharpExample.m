% im=imread('toBeSharpened.png');
im=imread('dark_pic.png');
filt=[0, -1, 0; -1, 5, -1; 0,-1,0]
result=imfilter(im,filt);

figure;
subplot(1,2,1); imshow(uint8(im));
subplot(1,2,2); imshow(uint8(result));
