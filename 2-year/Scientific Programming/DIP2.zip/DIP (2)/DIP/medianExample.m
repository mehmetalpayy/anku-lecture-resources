im=imread('elephant.png');
im=rgb2gray(im);
result1=medfilt2(im,[7,7]);
result2=medfilt2(im,[15,15]);

figure;
subplot(1,3,1); imshow(uint8(im));
subplot(1,3,2); imshow(uint8(result1));
subplot(1,3,3); imshow(uint8(result2));
