function [output] = histf(img)

%we want show [1-256] instead of [0-255]. So we add +1 to pixel.
output=zeros(1,256);
	[r, c] = size(img);
	for i=1:r    
		for j=1:c        
			pixel=img(i,j);        
			output(pixel+1) = output(pixel+1)+1;    
        end
    end

end

