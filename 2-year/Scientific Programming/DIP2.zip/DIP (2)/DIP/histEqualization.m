img = imread('dark_pic.png');
img=rgb2gray(img);
out = equalizeHistogram(img); 

histogram1 = histf(img);
histogram2 = histf(out);

figure; 
subplot(2,2,1); imshow(img); 
subplot(2,2,2); imshow(uint8(out)); 
subplot(2,2,3); bar(histogram1);
subplot(2,2,4); bar(histogram2);
