im = imread('averaging.png');
im=rgb2gray(im);
result1 = imfilter(im, ones(3,3)/9);
result2 = imfilter(im, ones(9,9)/81);
result3 = imfilter(im, ones(35,35)/1225);

figure;
subplot(2,2,1); imshow(uint8(im));
subplot(2,2,2); imshow(uint8(result1));
subplot(2,2,3); imshow(uint8(result2));
subplot(2,2,4); imshow(uint8(result3));
