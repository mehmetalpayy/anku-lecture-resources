% built-in function
im = imread('averaging.png');
im=rgb2gray(im);
result1 = imfilter(im, ones(3,3)/9);

%our implementation!

paddedIm=zeros(214,212);

paddedIm(2:213,2:211)=im;

filteredImage=zeros(212,210);

[r,c]=size(im);


for i=2:r+1
    for j=2:c+1
        
        newPixelValue=paddedIm(i,j)+paddedIm(i-1,j)+paddedIm(i+1,j)...
            +paddedIm(i,j-1)+paddedIm(i,j+1)...
            +paddedIm(i-1,j-1)+paddedIm(i+1,j+1)...
            +paddedIm(i-1,j+1)+paddedIm(i+1,j-1);
        newPixelValue=newPixelValue/9;
        
        filteredImage(i-1,j-1)=newPixelValue;
        
    end
    
end

filteredImage=uint8(filteredImage);

figure;
subplot(1,2,1); imshow(uint8(result1));
subplot(1,2,2); imshow(uint8(filteredImage));

if result1==filteredImage 
    disp('SAME RESULT'); 
else
    disp('DIFFERENT RESULT'); 
end