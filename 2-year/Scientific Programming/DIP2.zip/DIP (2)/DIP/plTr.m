function [output] = plTr(img)

c=100;
gamma=0.33;

output=c*img.^gamma;

end

