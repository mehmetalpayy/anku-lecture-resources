img=imread('moon_rgb.jpg'); 
img=rgb2gray(img);

%exp operates on double!
img = double(img)/255;

out=plTr(img);
figure;
subplot(1,2,1); imshow(img);
subplot(1,2,2); imshow(uint8(out));