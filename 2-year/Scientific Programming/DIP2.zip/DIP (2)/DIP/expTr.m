function [output] = expTr(img)


c=100;
output=c*exp(img);

end

